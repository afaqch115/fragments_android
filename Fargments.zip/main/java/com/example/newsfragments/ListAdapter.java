package com.example.newsfragments;

import android.content.Context;

import android.util.Log;
import android.view.LayoutInflater;

import android.view.View;

import android.view.ViewGroup;

import android.widget.ArrayAdapter;

import android.widget.TextView;

import org.json.JSONException;

import org.json.JSONObject;

import java.io.Console;
import java.util.ArrayList;

public class ListAdapter extends ArrayAdapter<JSONObject>{

    int vg;
    ArrayList<JSONObject> list;
    Context context;

    public ListAdapter(Context context, int vg, int id, ArrayList<JSONObject> list){
        super(context,vg, id,list);
        this.context=context;
        this.vg=vg;
        this.list=list;
    }
    public View getView(int position, View convertView, ViewGroup parent)
    {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemView = inflater.inflate(vg, parent, false);
        TextView txtName=(TextView)itemView.findViewById(R.id.txtname);
        Log.d("Check","Here "+vg);
        try
        {
           if(vg==R.layout.category_fragment)
                txtName.setText(list.get(position).getString("category"));
           else if(vg==R.layout.headline_fragment)
                txtName.setText(list.get(position).getString("headline"));
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return itemView;
    }
}

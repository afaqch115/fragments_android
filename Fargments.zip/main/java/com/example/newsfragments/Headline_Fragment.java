package com.example.newsfragments;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import android.telecom.Call;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


public class Headline_Fragment extends Fragment implements OnItemClickListener {
    View view;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViewsInLayout();
        view = inflater.inflate(R.layout.headline_fragment, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final JSONArray jsonArray=getJSonData("news.json");

        final ArrayList<JSONObject> listItems=getArrayListFromJSONArray(jsonArray);
        GetList li=new GetList();
        ListView listV=(ListView)view.findViewById(R.id.list);

        ListAdapter adapter=new ListAdapter(getActivity().getApplicationContext(),R.layout.headline_fragment,R.id.txtname,listItems);

        listV.setAdapter(adapter);
        listV.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle args = new Bundle();
                try
                {
                    args.putString("category",listItems.get(position).getString("category"));
                    args.putString("headline",listItems.get(position).getString("headline"));
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
                Details_Fragment fragment2 = new Details_Fragment();
                fragment2.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction =        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment1, fragment2);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
        Toast.makeText(getActivity(), "Item: " + position, Toast.LENGTH_SHORT).show();
    }

    private JSONArray getJSonData(String fileName){

        JSONArray jsonArray=null;

        try {

            InputStream is = getResources().getAssets().open(fileName);

            int size = is.available();

            byte[] data = new byte[size];

            is.read(data);

            is.close();

            String json = new String(data, "UTF-8");

            jsonArray=new JSONArray(json);

        }catch (IOException e){

            e.printStackTrace();

        }catch (JSONException je){

            je.printStackTrace();

        }

        return jsonArray;

    }

    private ArrayList<JSONObject> getArrayListFromJSONArray(JSONArray jsonArray){

        ArrayList<JSONObject> aList=new ArrayList<JSONObject>();
        String category=(this.getArguments().get("category")).toString();
        try {
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    if(jsonArray.getJSONObject(i).getString("category").equals(category))
                        aList.add(jsonArray.getJSONObject(i));
                }
            }
        }catch (JSONException je){je.printStackTrace();}

        return  aList;

    }
}


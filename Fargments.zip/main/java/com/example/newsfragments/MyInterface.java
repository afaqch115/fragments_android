package com.example.newsfragments;

import android.widget.*;

public interface MyInterface {
    ListView getListView();
}

package com.example.newsfragments;

import android.app.Activity;
import android.widget.ListView;

public class GetList extends Activity implements MyInterface {
    @Override
    public ListView getListView() {
        return findViewById(R.id.list);
    }
}

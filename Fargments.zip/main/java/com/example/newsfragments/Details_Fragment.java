package com.example.newsfragments;

import androidx.fragment.app.Fragment;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;



public class Details_Fragment extends Fragment implements OnItemClickListener {
    View view;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViewsInLayout();
        view = inflater.inflate(R.layout.details_fragment, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final JSONArray jsonArray=getJSonData("news.json");
        display(jsonArray);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
        Toast.makeText(getActivity(), "Item: " + position, Toast.LENGTH_SHORT).show();
    }

    private JSONArray getJSonData(String fileName){

        JSONArray jsonArray=null;

        try {

            InputStream is = getResources().getAssets().open(fileName);

            int size = is.available();

            byte[] data = new byte[size];

            is.read(data);

            is.close();

            String json = new String(data, "UTF-8");

            jsonArray=new JSONArray(json);

        }catch (IOException e){

            e.printStackTrace();

        }catch (JSONException je){

            je.printStackTrace();

        }

        return jsonArray;

    }

    private void display(JSONArray jsonArray){

        try
        {
        String category=(this.getArguments().get("category")).toString();
        String headline=(this.getArguments().get("headline")).toString();
        TextView headl=getActivity().findViewById(R.id.headline);
        TextView ctg=getActivity().findViewById(R.id.category);
        TextView author=getActivity().findViewById(R.id.author);
        TextView description=getActivity().findViewById(R.id.description);
        TextView published=getActivity().findViewById(R.id.published_at);

            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    if(jsonArray.getJSONObject(i).getString("category").equals(category) && jsonArray.getJSONObject(i).getString("headline").equals(headline))
                    {
                        headl.setText(jsonArray.getJSONObject(i).getString("headline"));
                        ctg.setText("Category: "+jsonArray.getJSONObject(i).getString("category"));
                        author.setText("Author: "+jsonArray.getJSONObject(i).getString("author"));
                        description.setText("Description: "+jsonArray.getJSONObject(i).getString("description"));
                        published.setText("Published At: "+jsonArray.getJSONObject(i).getString("publishedAt"));
                    }
                }
            }
        }catch (Exception je){je.printStackTrace();}


    }
}

